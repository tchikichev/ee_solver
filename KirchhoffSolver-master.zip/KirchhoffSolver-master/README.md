# KirchhoffSolver #

## 0.4.02 ##
## 23.11.2021 ##
### Authors:
* Aleksandr Maltsev <am@isgneuro.com>
* Yuriy Savchenko <yusavchenko@isgneuro.com>
* Denis Antipin <da@isgneuro.com>
* Sergey Romanov <sr@isgneuro.com>
* Sergey Ermilov <se@isgneuro.com>
* Igor Tokarev <it@isgneuro.com>
* Nikolay Ryabykh <nryabykh@isgneuro.com>

### How to install package:
pip install git+https://github.com/ISGNeuroTeam/KirchhoffSolver

OR

pip install git+https://github.com/ISGNeuroTeam/KirchhoffSolver@%BRANCH_NAME%

OR

git clone https://github.com/ISGNeuroTeam/KirchhoffSolver
pip install KirchhoffSolver\

### How to use:
look at showcase.py
