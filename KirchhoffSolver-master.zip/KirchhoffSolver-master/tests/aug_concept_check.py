from os import path
import pandas as pd
import numpy as np
from ksolver.io.calculate_DF import calculate_DF, calculate_PPD_from_nodes_edges_df, calculate_PPD_from_dfs
from ksolver.tools.viz import draw_result_graph
# import tests.config as config
from ksolver.tools.HE2_schema_maker import make_oilpipe_schema_from_OT_dataset
from ksolver.tools.HE2_tools import dump_graph_results_to_dicts, dump_graph_results_to_json_str
from ksolver.tools.HE2_ABC import Root
from ksolver.solver.HE2_Solver import HE2_Solver
from ksolver.graph.nodes.HE2_Vertices import is_source, HE2_Source_Vertex, HE2_ABC_GraphVertex, HE2_Boundary_Vertex
import networkx as nx
from numpy.random import Generator, PCG64
from make_me_small_oil_net import make_small_oil_tree_net



def make_well_augmentation_points_fast(well_name, snapshot, graph, bounds):
    suffixes = ['zaboi' ,'pump_intake', 'pump_outlet', 'wellhead']
    node_names = [well_name]
    node_names += [f'{well_name}_{suff}' for suff in suffixes]
    wellname_parts = well_name.split('_')
    well_num, pad_num = wellname_parts[1], wellname_parts[3]

    wellhead = node_names[-1]
    outlet = node_names[-2]
    intake = node_names[-3]
    zaboi = node_names[-4]
    P_wh = snapshot['nodes'][wellhead]['P_bar']
    Q_wh = snapshot['edges'][(outlet, wellhead, 0)]['x']
    Q_z =  snapshot['nodes'][intake]['Q']
    P_plast =  snapshot['nodes'][well_name]['P_bar']
    Freq = snapshot['edges'][(intake, outlet, 0)]['freq']
    P_intk = snapshot['nodes'][intake]['P_bar']
    fluid = graph.nodes[well_name]['obj'].fluid
    dens = snapshot['nodes'][intake]['LiquidDensity_SC_kg_m3']
    dyn_height = P_intk * 10**5 / dens / 9.81
    result = [(Freq, dyn_height, Q_z)]

    if Q_wh < 0:
        return result

    G1 = nx.DiGraph()
    G1.add_node(wellhead, obj = HE2_Boundary_Vertex("P", P_wh))
    G1.add_node(outlet, obj = HE2_ABC_GraphVertex())
    G1.add_node(intake, obj = HE2_Source_Vertex("Q", Q_wh, fluid, 20))
    pump_obj = graph[intake][outlet][0]['obj']
    G1.add_edge(intake, outlet, obj=pump_obj)
    G1.add_edge(outlet, wellhead, obj=graph[outlet][wellhead][0]['obj'])
    solver1 = HE2_Solver(G1)

    G2 = nx.DiGraph()
    G2.add_node(well_name, obj = HE2_Source_Vertex("P", P_plast, fluid, 20)) # This is plast
    G2.add_node(zaboi, obj = HE2_ABC_GraphVertex())
    G2.add_node(intake, obj = HE2_Boundary_Vertex("P", 10))
    G2.add_edge(well_name, zaboi, obj=graph[well_name][zaboi][0]['obj'])
    G2.add_edge(zaboi, intake, obj=graph[zaboi][intake][0]['obj'])
    solver2 = HE2_Solver(G2)
    solver2.solve(threshold=100500, it_limit=1, mix_fluids=False) # warm up solver

    P_intake_lo = bounds['dh'][0] * 9.81 * dens / 10**5
    P_intake_hi = bounds['dh'][1] * 9.81 * dens / 10**5
    new_bounds = dict(fr = bounds['fr'], p_intk = (P_intake_lo, P_intake_hi))

    def calc_Pi_and_Qz(fr):
        pump_obj.changeFrequency(fr)
        solver1.solve(threshold=0.15, it_limit=20, mix_fluids=False)
        if not solver1.op_result.success:
            return None
        P_intake = G1.nodes[intake]['obj'].result['P_bar']
        solver2.graph[Root][intake]['obj'].dP = P_intake
        solver2.solve(threshold=0.015, it_limit=20, mix_fluids=False)
        if not solver2.op_result.success:
            return None
        Q_from_plast = G2.nodes[well_name]['obj'].result['Q']
        Q_from_zatrub = Q_wh - Q_from_plast
        # assert Q_from_zatrub + Q_from_plast == Q_wh
        return P_intake, Q_from_zatrub

    zeroline = []
    freqs = np.linspace(*bounds['fr'], num=81)
    pivot = freqs.searchsorted(Freq)
    freqs_right = freqs[pivot:]
    freqs_left = freqs[:pivot]
    for fr in freqs_right:
        P_intake, Q_from_zatrub = calc_Pi_and_Qz(fr)
        if P_intake < P_intake_lo or P_intake > P_intake_hi:
            break
        zeroline += [(fr, P_intake, Q_from_zatrub)]

    for fr in freqs_left[::-1]:
        P_intake, Q_from_zatrub = calc_Pi_and_Qz(fr)
        if P_intake < P_intake_lo or P_intake > P_intake_hi:
            break
        dyn_height = P_intake * 10 ** 5 / dens / 9.81
        zeroline += [(fr, dyn_height, Q_from_zatrub)]


    result += zeroline
    result.sort()
    return result


def run_one_net(G, X):
    global wells_order
    wells_order = sorted([n for n in G.nodes if is_source(G, n) and n[:4]=='PAD_'])
    wells_count = len(wells_order)
    for i, n in enumerate(wells_order):
        intake = n + '_pump_intake'
        outlet = n + '_pump_outlet'
        fluid = G.nodes[n]['obj'].fluid
        dens = fluid.LiquidDensity_SC_kg_m3
        freq = X[2*i]
        h_dyn = X[2*i+1]
        P_intk = dens * 9.81 * h_dyn * 10**-5
        G.nodes[intake]['obj'] = HE2_Source_Vertex('P', P_intk, fluid, 20)
        pump_obj = G[intake][outlet][0]['obj']
        pump_obj.changeFrequency(freq)

    solver = HE2_Solver(G)
    solver.solve(it_limit=100, threshold=0.001)

    Y = np.zeros(2*wells_count)
    for i, well in enumerate(wells_order):
        intake_node = f"{well}_pump_intake"
        outlet_node = f"{well}_pump_outlet"
        pump_obj = G[intake_node][outlet_node][0]["obj"]
        total_debit = pump_obj.result['x']
        intake_obj = G.nodes[intake_node]['obj']
        debit_from_zatrub = intake_obj.result['Q']
        plast_obj = G.nodes[well]['obj']
        debit_from_plast = plast_obj.result['Q']
        np.testing.assert_almost_equal(total_debit, debit_from_plast + debit_from_zatrub)

        Y[i * 2] = total_debit
        Y[i * 2 + 1] = debit_from_zatrub

    gr = dump_graph_results_to_dicts(G)

    return Y, gr

if __name__ == '__main__':
    p, w, r = 10, 50, 42
    data_folder = 'C:\work\IsNeugro\TajlakiData'
    wells_order = []
    X1 = np.array([50, 300]*178)
    G1 = make_small_oil_tree_net(p, w, r)
    Y1, gr1 = run_one_net(G1, X1)
    json1 = dump_graph_results_to_json_str(**gr1)

    well_idx = 0
    well = wells_order[well_idx]
    bounds = dict(fr=(40, 60), dh=(100, 800))
    G2 = make_small_oil_tree_net(p, w, r)
    zeroline = make_well_augmentation_points_fast(well, gr1, G2, bounds)
    pnt = zeroline[0]
    X2 = X1.copy()
    X2[2*well_idx] = pnt[0]
    X2[2*well_idx+1] = pnt[1]
    G3 = make_small_oil_tree_net(p, w, r)
    Y2, gr2 = run_one_net(G3, X2)
    json2 = dump_graph_results_to_json_str(**gr2)
    print(json1)
    print(json2)

    np.set_printoptions(suppress=True)
    print(Y1)
    print(Y2)
    print(np.linalg.norm(Y1-Y2))
    print(Y1-Y2)
    pass

