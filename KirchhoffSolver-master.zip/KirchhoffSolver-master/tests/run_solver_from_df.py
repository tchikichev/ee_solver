# import config
from os import path
import pandas as pd
from ksolver.io.calculate_DF import calculate_DF, calculate_PPD_from_dfs, ad_hoc_convert_ppd_two_df_to_single_df, ad_hoc_join_wells_to_ppd_single_df
# import tests.config as config
import config

import otp

def test1():
    selection_dict = {
        "КНС 1": "KNS1_.csv",
        "КНС 2": "KNS2.csv"
    }
    option = "КНС 1"
    eff_diam = 0.85

    # data_folder = r'../../data/'
    data_folder = r'../data/'

    effectiveD = "effectiveD"
    startIsSource = "start_is_source"
    node_name_start = "node_name_start"
    startValue = "startValue"
    VolumeWater = "VolumeWater"
    endIsOutlet = "endIsOutlet"
    node_id_end = "node_id_end"
    endValue = "endValue"

    df_filename = path.join(data_folder, selection_dict[option])
    dataset = pd.read_csv(df_filename)
    # dataset[effectiveD] = eff_diam
    # mask = dataset[startIsSource] == True
    # inlets_df = dataset[mask]
    # inlets_dict = {}
    mdf, G = calculate_DF(dataset, data_folder, return_graph=True, network_kind='water')
    pass


# @st.cache(persist=True)
def get_kns_pumps_best_charts_collection():
    full_collection = dict()
    best = dict()
    query = '| get path=FS/PPD/pump_curves_water'
    df = otp.get_data(query)
    for sf in df.source_file.unique():
        df2 = df[df.source_file == sf]
        full_collection[sf] = df2
        model = df2.model.values[0]
        serial_number = df2.serial_number.values[0]
        key = (model, serial_number)
        dt = df2.dt.values[0]
        cnt = df2.shape[0]

        cnt2, dt2, sf2 = best.get(key, (-1, -1, ''))
        if (cnt2==-1) or (dt > dt2) or (dt == dt2 and cnt > cnt2):
            best[key] = (cnt, dt, sf)

    best_dfs = [full_collection[ best[k][2] ] for k in best]
    df = pd.concat(best_dfs)
    df = df[['model', 'flow_m3_per_hour', 'head_m', 'efficiency_percent', 'power_kW', 'serial_number']]
    df.columns = ['pumpModel', 'debit', 'pressure', 'eff', 'power', 'serial_number']
    df['debit'] = df['debit'] * 24
    df['power'] = df['power'] * 1000

    return df, list(best.keys())



def test2():
    data_folder = config.get_data_folder()
    df_nodes = pd.read_csv(path.join(data_folder, 'tmp_nodes.csv'))
    df_edges = pd.read_csv(path.join(data_folder, 'tmp_edges.csv'))
    kns_pumps, models = get_kns_pumps_best_charts_collection()
    df_well_pumps = pd.read_csv(path.join(data_folder, "PumpChart.csv"))
    df_inclination =  pd.read_parquet(path.join(data_folder, "inclination"), engine="pyarrow")
    df_HKT = pd.read_parquet(path.join(data_folder, "HKT"), engine="pyarrow")

    df_dict = dict(nodes=df_nodes,edges=df_edges,kns_pumps=kns_pumps, well_pumps=df_well_pumps, inclination=df_inclination, HKT=df_HKT)
    rez_nodes, rez_edges, G = calculate_PPD_from_dfs(df_dict)

def test3():
    data_folder = config.get_data_folder()
    dataset = pd.read_csv(path.join(data_folder, "dns_wells.csv"))
    mdf = calculate_DF(dataset, data_folder=data_folder, solver_params=dict(threshold=2))

def test4():
    data_folder = config.get_data_folder()
    dataset = pd.read_csv(path.join(data_folder, "1234.csv"))
    mdf = calculate_DF(dataset, data_folder=data_folder, solver_params=dict(threshold=0.01, it_limit=1000))
    mdf.to_csv(path.join(data_folder, "1234_rez.csv"), index=False)

def test5():
    # Берем для кнс-1 два дф - еджи и ноды, джойним их в один дф - сеть
    # полученый дф может быть расчитан солвером

    data_folder = config.get_data_folder()
    df_edges = pd.read_csv(path.join(data_folder,'kns_1 wo wells edges.csv'), index_col=0)
    df_nodes = pd.read_csv(path.join(data_folder,'kns_1 wo wells nodes.csv'), index_col=0)
    dfs = dict(edges = df_edges, nodes = df_nodes)
    rez_df = ad_hoc_convert_ppd_two_df_to_single_df(dfs)
    rez_df.to_csv(path.join(data_folder, 'kns1_merged.csv'), index=False)


def test6():
    # Расчитываем солвером дф сети кнс-1

    data_folder = config.get_data_folder()
    dataset = pd.read_csv(path.join(data_folder, "kns1_merged.csv"))
    mdf = calculate_DF(dataset, data_folder=data_folder, solver_params=dict(threshold=0.01, it_limit=1000), network_kind='water')
    mdf.to_csv(path.join(data_folder, "kns1_merged_rez.csv"), index=False)

def test7():
    data_folder = config.get_data_folder()
    df_nodes = pd.read_csv(path.join(data_folder, 'kns_1 wo wells nodes.csv'))
    df_edges = pd.read_csv(path.join(data_folder, 'kns_1 wo wells edges.csv'))
    # kns_pumps, models = get_kns_pumps_best_charts_collection()
    df_well_pumps = pd.read_csv(path.join(data_folder, "PumpChart.csv"))
    df_inclination =  pd.read_parquet(path.join(data_folder, "inclination"), engine="pyarrow")
    df_HKT = pd.read_parquet(path.join(data_folder, "HKT"), engine="pyarrow")

    df_dict = dict(nodes=df_nodes,edges=df_edges, well_pumps=df_well_pumps, inclination=df_inclination, HKT=df_HKT)
    rez_nodes, rez_edges, G = calculate_PPD_from_dfs(df_dict)

def test8():
    # Берем дф сети кнс-1, и дф скважин кнс-1 (формат отл-запроса Дениса)
    # Объединяем их в один дф
    # Запускаем на объединенном дф солвер, сохраняем результаты в дф
    data_folder = config.get_data_folder()
    ppd_df = pd.read_csv(path.join(data_folder, "kns1_merged.csv"))
    wells_df = pd.read_csv(path.join(data_folder, "kns_1 wells.csv"))
    rez = ad_hoc_join_wells_to_ppd_single_df(wells_df, ppd_df)
    rez.to_csv(path.join(data_folder, "kns1_net_and_wells.csv"), index=False)
    mdf = calculate_DF(rez, data_folder=data_folder, solver_params=dict(threshold=0.01, it_limit=1000), network_kind='water')
    mdf.to_csv(path.join(data_folder, "kns1_net_and_wells_rez.csv"), index=False)


if __name__ == '__main__':
    test8()
    # test5()
    # test6()